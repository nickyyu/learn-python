import sqlite3
import os

class DatabaseManager:
    def __init__(self, db_path="data/dev_assistant.db"):
        # 确保数据目录存在
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db_path = db_path
        self._init_db()

    def _get_connection(self):
        """获取数据库连接，设置 row_factory 使返回结果像字典一样可访问"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row  # 关键：允许通过列名访问，如 row['title']
        return conn

    def _init_db(self):
        """初始化表结构"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # 1. 需求主表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    desc TEXT,
                    status TEXT DEFAULT 'Open'
                )
            """)
            # 2. 项目关联表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS task_links (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id INTEGER,
                    project_path TEXT NOT NULL,
                    branch_name TEXT NOT NULL,
                    remote_project_id TEXT,
                    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
                )
            """)
            # 3. 合并历史表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS merge_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    link_id INTEGER,
                    target_branch TEXT,
                    mr_url TEXT,
                    status TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (link_id) REFERENCES task_links(id) ON DELETE CASCADE
                )
            """)
            conn.commit()

    # --- 业务逻辑方法 ---

    def get_all_tasks(self):
        """查询所有任务列表"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM tasks ORDER BY id DESC")
            return [dict(row) for row in cursor.fetchall()]

    def get_task_links(self, task_id):
        """查询某个需求关联的所有项目"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM task_links WHERE task_id = ?", (task_id,))
            return [dict(row) for row in cursor.fetchall()]

    def add_project_link(self, task_id, path, branch):
        """添加一个新的项目关联"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO task_links (task_id, project_path, branch_name) VALUES (?, ?, ?)",
                (task_id, path, branch)
            )
            conn.commit()
            return cursor.lastrowid

    def add_merge_log(self, link_id, target, url, status="Reviewing"):
        """记录一次合并操作"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO merge_history (link_id, target_branch, mr_url, status) VALUES (?, ?, ?, ?)",
                (link_id, target, url, status)
            )
            conn.commit()

    def update_mr_status(self, link_id, new_status):
        """更新 MR 状态（供 StatusPoller 调用）"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE merge_history SET status = ? WHERE link_id = ? AND status != 'merged'",
                (new_status, link_id)
            )
            conn.commit()
            
    def get_mrs_by_status(self, status):
        """查询特定状态的 MR（用于轮询）"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # 联合查询，拿到远程 ID 以便调用 API
            cursor.execute("""
                SELECT h.id, h.link_id, l.remote_project_id, h.mr_url, h.status 
                FROM merge_history h
                JOIN task_links l ON h.link_id = l.id
                WHERE h.status = ?
            """, (status,))
            return [dict(row) for row in cursor.fetchall()]