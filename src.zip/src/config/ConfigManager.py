from PySide6.QtCore import QSettings

class ConfigManager:
    """处理配置的读取、写入与默认值管理"""
    def __init__(self):
        # 组织名与应用名决定了配置存储的路径
        self.settings = QSettings("DevAssistantTeam", "RDRobot")

    def get_token(self):
        return self.settings.value("git/token", "")

    def set_token(self, token):
        self.settings.setValue("git/token", token)

    def get_git_path(self):
        return self.settings.value("git/path", "git") # 默认假设在环境变量中

    def get_target_branches(self):
        # 返回列表，若无则返回默认流
        return self.settings.value("git/target_branches", ["dev", "test", "master"])

    def save_all(self, token, git_path, branches):
        self.settings.setValue("git/token", token)
        self.settings.setValue("git/path", git_path)
        self.settings.setValue("git/target_branches", branches)