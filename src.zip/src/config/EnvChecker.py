import subprocess
import requests

class EnvChecker:
    @staticmethod
    def check_git(git_path="git"):
        """检查本地 Git 是否可用"""
        try:
            res = subprocess.run([git_path, "--version"], capture_output=True, text=True)
            return res.returncode == 0, res.stdout.strip()
        except FileNotFoundError:
            return False, "未找到 Git 可执行文件"

    @staticmethod
    def validate_token(base_url, token):
        """验证 GitLab Token 有效性"""
        try:
            # 访问 /user 接口是最轻量的校验方式
            headers = {"PRIVATE-TOKEN": token}
            response = requests.get(f"{base_url}/api/v4/user", headers=headers, timeout=5)
            if response.status_code == 200:
                return True, f"验证成功: Hi, {response.json().get('name')}"
            return False, f"验证失败 (HTTP {response.status_code})"
        except Exception as e:
            return False, f"网络连接异常: {str(e)}"