import sys
import os
from PySide6.QtWidgets import QApplication, QMessageBox
from PySide6.QtCore import QThreadPool
from ui.MainWindow import MainWindow
from config.ConfigManager import ConfigManager
from database.DatabaseManager import DatabaseManager
from config.EnvChecker import EnvChecker

# 导入我们之前设计的各个模块
# from database import DatabaseManager
# from config import ConfigManager, EnvChecker
# from ui import MainWindow, SettingsDialog

class AppContext:
    """全局上下文对象，持有共享资源的引用"""
    def __init__(self):
        self.config = ConfigManager()
        self.db = DatabaseManager()
        self.thread_pool = QThreadPool.globalInstance()
        # 设置线程池最大并发数，避免 Git 操作过多占用 CPU
        self.thread_pool.setMaxThreadCount(4)

def main():
    # 1. 初始化应用（启用高 DPI 支持）
    app = QApplication(sys.argv)
    app.setApplicationName("RD-Assistant")
    app.setOrganizationName("DevTools-Inc")

    # 2. 初始化上下文
    ctx = AppContext()

    # 3. 实例化主窗口
    window = MainWindow(ctx)

    # 4. 执行启动自检
    # 如果 Git 没装或者 Token 为空，弹出提示并引导至设置
    git_ok, _ = EnvChecker.check_git(ctx.config.get_git_path())
    token_exists = len(ctx.config.get_token()) > 0

    if not git_ok or not token_exists:
        msg = "检测到环境配置不完整：\n"
        if not git_ok: msg += "- 本地未找到 Git 可执行文件\n"
        if not token_exists: msg += "- 未配置 GitLab Access Token\n"
        msg += "\n点击确定进入设置界面。"
        
        QMessageBox.information(None, "系统引导", msg)
        
        # 强制弹出设置窗口
        from ui import SettingsDialog
        settings = SettingsDialog(ctx.config)
        if settings.exec() != SettingsDialog.Accepted:
            # 如果用户在引导阶段点击取消，则直接退出程序
            sys.exit(0)

    # 5. 显示主窗口并进入事件循环
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()