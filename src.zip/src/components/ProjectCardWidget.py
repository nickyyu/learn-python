from PySide6.QtWidgets import QWidget
from PySide6.QtCore import  Signal, Slot


class ProjectCardWidget(QWidget):
    # 定义信号：(项目路径, 目标分支, link_id)
    request_merge = Signal(str, str, int) 

    def __init__(self, link_data):
        super().__init__()
        self.link_id = link_data['id']
        # 初始化 UI 和合并历史表格...
        
    @Slot()
    def on_merge_clicked(self):
        target_branch = self.branch_input.text()
        self.request_merge.emit(self.path, target_branch, self.link_id)