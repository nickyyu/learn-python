from PySide6.QtWidgets import (QDialog, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QDialogButtonBox, QMessageBox)
from config.EnvChecker import EnvChecker 

class SettingsDialog(QDialog):
    def __init__(self, config_manager, parent=None):
        super().__init__(parent)
        self.cfg = config_manager
        self.setWindowTitle("全局配置与自检")
        self.setMinimumWidth(400)
        
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.token_input = QLineEdit(self.cfg.get_token())
        self.token_input.setEchoMode(QLineEdit.Password)
        
        self.git_path_input = QLineEdit(self.cfg.get_git_path())
        
        self.test_btn = QPushButton("测试 Token 连接")
        self.test_btn.clicked.connect(self.on_test_connection)

        form.addRow("GitLab Token:", self.token_input)
        form.addRow("Git 可执行路径:", self.git_path_input)
        form.addRow("", self.test_btn)
        
        layout.addLayout(form)

        # 标准按钮
        self.btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        self.btns.accepted.connect(self.on_save)
        self.btns.rejected.connect(self.reject)
        layout.addWidget(self.btns)

    def on_test_connection(self):
        # 此处简单硬编码了 Base URL，实际应从配置中读取
        base_url = "https://gitlab.com" 
        success, msg = EnvChecker.validate_token(base_url, self.token_input.text())
        
        if success:
            QMessageBox.information(self, "测试结果", msg)
        else:
            QMessageBox.warning(self, "测试结果", msg)

    def on_save(self):
        self.cfg.set_token(self.token_input.text())
        self.cfg.settings.setValue("git/path", self.git_path_input.text())
        self.accept()