from PySide6.QtWidgets import QDialog,QSystemTrayIcon, QStyle,QMainWindow,QWidget,QHBoxLayout,QVBoxLayout,QListWidget,QLabel,QPushButton,QScrollArea,QFileDialog,QInputDialog,QMessageBox
from PySide6.QtCore import QThreadPool,Slot
from database import DatabaseManager
from git import GitWorker
from components import ProjectCardWidget
from config.ConfigManager import ConfigManager
from StatusPoller import StatusPoller
from config.EnvChecker import EnvChecker
from SettingsDialog import SettingsDialog

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("研发助手 - 桌面版")
        self.resize(1000, 700)
        
        # 初始化核心组件
        self.db = DatabaseManager()
        self.thread_pool = QThreadPool.globalInstance()
        self.current_task_id = None
        
        self._init_ui()
        self._load_tasks()
        self.cfg = ConfigManager()
        # ... 初始化 UI ...
        # 初始化系统托盘（用于发送通知）
        self.tray_icon = QSystemTrayIcon(self)
        self.tray_icon.setIcon(self.style().standardIcon(QStyle.SP_ComputerIcon))
        self.tray_icon.show()

        # 初始化轮询器
        self.poller = StatusPoller(self.db, self.adapter)
        self.poller.status_changed.connect(self.on_mr_status_updated)
        self.poller.start()

    def _init_ui(self):
        """初始化整体布局"""
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QHBoxLayout(main_widget)

        # 1. 左侧需求列表
        self.task_list = QListWidget()
        self.task_list.setFixedWidth(250)
        self.task_list.currentRowChanged.connect(self.on_task_selected)
        layout.addWidget(self.task_list)

        # 2. 右侧详情容器
        detail_container = QWidget()
        self.detail_layout = QVBoxLayout(detail_container)
        
        # 2.1 需求基础信息展示区
        self.info_label = QLabel("请选择一个需求")
        self.info_label.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.detail_layout.addWidget(self.info_label)
        
        # 2.2 添加项目按钮
        self.add_proj_btn = QPushButton("关联新项目 (Add Project)")
        self.add_proj_btn.clicked.connect(self.on_add_project_clicked)
        self.add_proj_btn.setEnabled(False)
        self.detail_layout.addWidget(self.add_proj_btn)

        # 2.3 核心：动态卡片滚动区
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.card_container = QWidget()
        self.card_layout = QVBoxLayout(self.card_container)
        self.card_layout.setAlignment(Qt.AlignTop) # 卡片靠上对齐
        self.scroll_area.setWidget(self.card_container)
        
        self.detail_layout.addWidget(self.scroll_area)
        layout.addWidget(detail_container)

    def _load_tasks(self):
        """初始化从数据库加载任务列表"""
        tasks = self.db.get_all_tasks() # 假设 DB 类有此方法
        for task in tasks:
            self.task_list.addItem(task['title'])
            # 存储 task_id 在 DataRole 中以便后续查询
            self.task_list.item(self.task_list.count()-1).setData(Qt.UserRole, task['id'])

    @Slot(int)
    def on_task_selected(self, index):
        """核心逻辑：切换需求时刷新右侧面板"""
        if index < 0: return
        
        item = self.task_list.item(index)
        self.current_task_id = item.data(Qt.UserRole)
        self.info_label.setText(f"当前需求: {item.text()}")
        self.add_proj_btn.setEnabled(True)

        # 1. 【重点】清理旧卡片
        self._clear_project_cards()

        # 2. 从数据库加载关联项目并实例化卡片
        links = self.db.get_task_links(self.current_task_id)
        for link in links:
            self._create_project_card(link)

    def _clear_project_cards(self):
        """
        核心：安全地清空布局并释放内存
        直接使用 layout.takeAt 循环确保 Widget 被正确从父级剥离并销毁
        """
        while self.card_layout.count():
            item = self.card_layout.takeAt(0)
            widget = item.widget()
            if widget:
                # 这种方式会触发 Python 的垃圾回收，并调用 C++ 层的析构函数
                widget.deleteLater() 

    def _create_project_card(self, link_data):
        """封装卡片创建逻辑及信号绑定"""
        card = ProjectCardWidget(link_data)
        
        # 绑定卡片内部信号到 MainWindow 的异步处理方法
        card.request_merge.connect(self.handle_git_merge)
        card.request_checkout.connect(self.handle_git_checkout)
        
        self.card_layout.addWidget(card)

    @Slot()
    def on_add_project_clicked(self):
        """追加关联项目逻辑"""
        path = QFileDialog.getExistingDirectory(self, "选择 Git 项目根目录")
        if not path: return
        
        branch, ok = QInputDialog.getText(self, "分支关联", "请输入该需求对应的开发分支名:")
        if ok and branch:
            # 1. 写入数据库
            new_link_id = self.db.add_project_link(self.current_task_id, path, branch)
            # 2. 动态追加 UI (无需刷新整个页面)
            link_data = {'id': new_link_id, 'project_path': path, 'branch_name': branch}
            self._create_project_card(link_data)

    def handle_git_merge(self, path, target_branch, link_id):
        """执行异步 Git 合并逻辑"""
        worker = GitWorker("merge", path, {"target": target_branch})
        
        # 信号反馈处理
        worker.signals.result.connect(lambda success, msg: self._on_git_finished(success, msg, link_id))
        self.thread_pool.start(worker)
        
    def _on_git_finished(self, success, msg, link_id):
        """Git 操作完成后的 UI 刷新"""
        if success:
            QMessageBox.information(self, "成功", "Git 合并完成！")
            # 可以在此处通过 link_id 找到对应的 ProjectCardWidget 刷新其历史表格
        else:
            QMessageBox.critical(self, "失败", f"Git 操作失败: {msg}")

    @Slot(int, str, str)
    def on_mr_status_updated(self, link_id, old_status, new_status):
        """处理状态变更"""
        # 1. 寻找对应的 ProjectCard 并通知它刷新 UI
        for i in range(self.card_layout.count()):
            widget = self.card_layout.itemAt(i).widget()
            if isinstance(widget, ProjectCardWidget) and widget.link_id == link_id:
                widget.refresh_status(new_status)
                break
        
        # 2. 如果是关键状态变更，发送托盘通知
        if new_status.lower() == "merged":
            self.tray_icon.showMessage(
                "合并成功！",
                f"关联项目 {link_id} 的代码已成功合入主干。",
                QSystemTrayIcon.Information,
                5000 # 显示 5 秒
            )

    def closeEvent(self, event):
        """窗口关闭时停止轮询，释放资源"""
        self.poller.stop()
        super().closeEvent(event)

    def startup_check(self):
        """应用启动时的环境自检"""
        # 1. 检查 Git
        git_ok, git_msg = EnvChecker.check_git(self.cfg.get_git_path())
        # 2. 检查 Token
        token_ok = len(self.cfg.get_token()) > 20 # 简单长度判断
        
        if not git_ok or not token_ok:
            reason = "未检测到 Git" if not git_ok else "未配置 Token"
            QMessageBox.warning(self, "环境不完整", f"{reason}，请先完善配置。")
            self.show_settings()

    def show_settings(self):
        dialog = SettingsDialog(self.cfg, self)
        if dialog.exec() == QDialog.Accepted:
            # 重新初始化某些需要配置的服务
            pass