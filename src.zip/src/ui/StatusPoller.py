from PySide6.QtCore import QObject, QTimer, Signal, Slot
from PySide6.QtWidgets import QSystemTrayIcon,QWidget

class StatusPoller(QObject):
    """
    状态轮询器：负责监控所有处于 'Reviewing' 状态的 MR
    """
    # 信号：(link_id, old_status, new_status)
    status_changed = Signal(int, str, str) 
    
    def __init__(self, db_manager, adapter, interval_ms=60000):
        super().__init__()
        self.db = db_manager
        self.adapter = adapter
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.check_active_mrs)
        self.interval = interval_ms

    def start(self):
        self.timer.start(self.interval)

    def stop(self):
        self.timer.stop()

    @Slot()
    def check_active_mrs(self):
        """核心逻辑：遍历本地数据库中处于中间态的 MR"""
        active_mrs = self.db.get_mrs_by_status("Reviewing")
        
        for mr in active_mrs:
            # 这里的 mr 包含 link_id, remote_project_id, mr_iid 等
            remote_status = self.adapter.get_mr_status(
                mr['remote_project_id'], 
                mr['mr_iid']
            )
            
            # 如果远程状态与本地不一致，则更新
            if remote_status.lower() != mr['status'].lower():
                self._update_and_notify(mr['link_id'], mr['status'], remote_status)

    def _update_and_notify(self, link_id, old_status, new_status):
        # 1. 更新数据库
        self.db.update_mr_status(link_id, new_status)
        # 2. 发射信号通知 UI
        self.status_changed.emit(link_id, old_status, new_status)