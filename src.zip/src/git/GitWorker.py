from PySide6.QtCore import QObject, QRunnable, Signal, Slot

class GitSignals(QObject):
    """专门用于 Worker 线程与 UI 线程通信的信号类"""
    started = Signal(str)      # 开始执行的操作名
    result = Signal(bool, str) # 执行结果 (成功/失败, 消息或URL)
    finished = Signal()        # 任务结束
class GitWorker(QRunnable):
    def __init__(self, action_type, repo_path, params, adapter=None):
        super().__init__()
        self.signals = GitSignals()
        self.action_type = action_type
        self.repo_path = repo_path
        self.params = params
        self.adapter = adapter # 传入配置好的适配器

    def run(self):
        try:
            if self.action_type == "push_and_mr":
                # 1. 执行本地 Push (伪代码)
                # subprocess.run(["git", "push", ...], cwd=self.repo_path)
                
                # 2. 调用远程 API 创建 MR
                if self.adapter:
                    res = self.adapter.create_mr(
                        self.params['project_id'],
                        self.params['source'],
                        self.params['target'],
                        self.params['title']
                    )
                    mr_url = res.get("web_url", "No URL")
                    self.signals.result.emit(True, f"MR Created: {mr_url}")
                else:
                    self.signals.result.emit(True, "Push success (No remote adapter)")
        except Exception as e:
            self.signals.result.emit(False, str(e))