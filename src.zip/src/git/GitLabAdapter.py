import requests
from abc import ABC, abstractmethod

class GitPlatformAdapter(ABC):
    """远程平台抽象基类"""
    @abstractmethod
    def create_mr(self, project_id, source, target, title) -> dict:
        pass

    @abstractmethod
    def get_mr_status(self, project_id, mr_id) -> str:
        pass

class GitLabAdapter(GitPlatformAdapter):
    def __init__(self, base_url, token):
        self.base_url = base_url.rstrip('/')
        self.headers = {"PRIVATE-TOKEN": token}

    def create_mr(self, project_id, source, target, title):
        url = f"{self.base_url}/api/v4/projects/{project_id}/merge_requests"
        data = {
            "source_branch": source,
            "target_branch": target,
            "title": title,
            "remove_source_branch": False
        }
        response = requests.post(url, headers=self.headers, json=data, timeout=10)
        return response.json() # 包含 iid, web_url 等

    def get_mr_status(self, project_id, mr_id):
        url = f"{self.base_url}/api/v4/projects/{project_id}/merge_requests/{mr_id}"
        response = requests.get(url, headers=self.headers, timeout=10)
        # 返回：can_be_merged, merged, closed 等状态
        return response.json().get("state", "unknown")