
import sys
from PySide6.QtWidgets import QApplication
from ui.main_window import MainWindow
from dao.db import init_db

def main():
    init_db()
    app = QApplication(sys.argv)
    w = MainWindow()
    w.resize(1000, 600)
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
