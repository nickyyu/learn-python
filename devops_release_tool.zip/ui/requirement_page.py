
from PySide6.QtWidgets import *

class RequirementPage(QWidget):

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["JIRA", "标题"])

        btn = QPushButton("新增需求")

        layout.addWidget(self.table)
        layout.addWidget(btn)

        self.setLayout(layout)
