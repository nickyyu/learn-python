
from PySide6.QtWidgets import *

class ReleasePage(QWidget):

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        self.table = QTableWidget()
        self.table.setColumnCount(6)

        self.table.setHorizontalHeaderLabels([
            "需求",
            "项目",
            "SIT",
            "UAT",
            "PRE",
            "PROD"
        ])

        layout.addWidget(self.table)

        self.setLayout(layout)
