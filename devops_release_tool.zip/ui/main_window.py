
from PySide6.QtWidgets import *
from ui.requirement_page import RequirementPage
from ui.release_page import ReleasePage

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("DevOps 发布工具")

        tabs = QTabWidget()

        tabs.addTab(RequirementPage(), "需求管理")
        tabs.addTab(ReleasePage(), "发布看板")

        self.setCentralWidget(tabs)
