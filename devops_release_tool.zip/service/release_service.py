
class ReleaseService:

    def __init__(self, gitlab, jenkins):
        self.gitlab = gitlab
        self.jenkins = jenkins

    def release(self, project_id, branch, target_branch, job):

        mr = self.gitlab.create_merge_request(
            project_id,
            branch,
            target_branch,
            f"{branch}->{target_branch}"
        )

        self.jenkins.build(job, {
            "branch": target_branch
        })

        return mr
