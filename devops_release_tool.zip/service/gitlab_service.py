
import requests

class GitLabService:

    def __init__(self, base_url, token):
        self.base_url = base_url
        self.token = token

    def create_branch(self, project_id, branch, ref="develop"):
        url = f"{self.base_url}/api/v4/projects/{project_id}/repository/branches"
        headers = {"PRIVATE-TOKEN": self.token}
        data = {"branch": branch, "ref": ref}
        r = requests.post(url, headers=headers, data=data)
        return r.json()

    def create_merge_request(self, project_id, source, target, title):
        url = f"{self.base_url}/api/v4/projects/{project_id}/merge_requests"
        headers = {"PRIVATE-TOKEN": self.token}
        data = {
            "source_branch": source,
            "target_branch": target,
            "title": title
        }
        r = requests.post(url, headers=headers, data=data)
        return r.json()
