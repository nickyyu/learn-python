
import requests

class JenkinsService:

    def __init__(self, base_url, user, token):
        self.base_url = base_url
        self.auth = (user, token)

    def build(self, job, params):
        url = f"{self.base_url}/job/{job}/buildWithParameters"
        r = requests.post(url, params=params, auth=self.auth)
        return r.status_code
