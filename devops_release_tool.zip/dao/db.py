
import sqlite3

DB_NAME = "release.db"

def get_conn():
    return sqlite3.connect(DB_NAME)

def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS requirement(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        jira_id TEXT,
        title TEXT
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS project(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        gitlab_project_id TEXT
    )
    """)

    conn.commit()
    conn.close()
